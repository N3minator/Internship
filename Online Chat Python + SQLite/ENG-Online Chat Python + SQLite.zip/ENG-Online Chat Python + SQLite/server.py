import socket
import threading
from datetime import datetime
from database import Session, engine, Base
from models import ChatMessage

import os
os.environ["TCL_LIBRARY"] = r"C:\Users\Виталик\AppData\Local\Programs\Python\Python313\tcl\tcl8.6"
os.environ["TK_LIBRARY"] = r"C:\Users\Виталик\AppData\Local\Programs\Python\Python313\tcl\tk8.6"

Base.metadata.create_all(engine)

HOST = '127.0.0.1'
PORT = 9099

# List of Clients
clients = {}


def broadcast(message, exclude_client=None):

    # Sends a message to all connected clients.

    for client_socket in list(clients.keys()):
        if client_socket != exclude_client:
            try:
                client_socket.sendall((message + "\n").encode('utf-8'))
            except:
                pass


def broadcast_online_users():

    # "ONLINE_USERS:<N>" and broadcasts the message to all clients, but it will be intercepted in "client". For online statistics

    user_list = list(clients.values())
    n = len(user_list)
    msg = "ONLINE_USERS:" + str(n) + " " + " ".join(user_list)
    broadcast(msg)


def handle_client(client_socket):
    session_db = Session()
    try:
        # Getting the username
        username = client_socket.recv(1024).decode('utf-8').strip()
        clients[client_socket] = username

        # Sending the chat history to the client
        history = session_db.query(ChatMessage).order_by(ChatMessage.timestamp.asc()).all()
        for msg in history:
            t_str = msg.timestamp.strftime('%d-%m-%y %H:%M')
            line = f"[{t_str}] {msg.username}: {msg.message}"
            client_socket.sendall((line + "\n").encode('utf-8'))

        # System message about joining
        join_text = f'==> "{username}" joined the chat'
        join_msg = ChatMessage(username="System", message=join_text)
        session_db.add(join_msg)
        session_db.commit()

        t_str = join_msg.timestamp.strftime('%d-%m-%y %H:%M')
        broadcast_line = f"[{t_str}] System: {join_text}"
        broadcast(broadcast_line)

        # We update the list online
        broadcast_online_users()

        # Main message receiving cycle
        while True:
            data = client_socket.recv(1024)
            if not data:
                break

            message_text = data.decode('utf-8').strip()
            if message_text:
                new_msg = ChatMessage(username=username, message=message_text)
                session_db.add(new_msg)
                session_db.commit()

                t_str = new_msg.timestamp.strftime('%d-%m-%y %H:%M')
                broadcast_line = f"[{t_str}] {username}: {message_text}"
                broadcast(broadcast_line)

    except Exception as e:
        print("Error in handle_client:", e)

    finally:
        # Disabling a user
        client_socket.close()
        if client_socket in clients:
            left_user = clients[client_socket]
            del clients[client_socket]

            # System exit message
            left_text = f'==> "{left_user}" left the chat'
            left_msg = ChatMessage(username="System", message=left_text)
            session_db.add(left_msg)
            session_db.commit()

            t_str = left_msg.timestamp.strftime('%d-%m-%y %H:%M')
            broadcast_line = f"[{t_str}] System: {left_text}"
            broadcast(broadcast_line)

            # We are sending the list online again
            broadcast_online_users()

        session_db.close()


def main():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind((HOST, PORT))
    server_socket.listen(5)
    print(f"The server is running on {HOST}:{PORT}. Waits clients...")

    while True:
        client_socket, addr = server_socket.accept()
        print(f"New connection: {addr}")
        client_thread = threading.Thread(target=handle_client, args=(client_socket,))
        client_thread.start()


if __name__ == "__main__":
    main()
