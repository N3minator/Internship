import socket
import threading
import tkinter as tk
from tkinter import simpledialog, scrolledtext

import os
os.environ["TCL_LIBRARY"] = r"C:\Users\Виталик\AppData\Local\Programs\Python\Python313\tcl\tcl8.6"
os.environ["TK_LIBRARY"] = r"C:\Users\Виталик\AppData\Local\Programs\Python\Python313\tcl\tk8.6"

HOST = '127.0.0.1'
PORT = 9099


class ChatClient:
    def __init__(self, master):
        self.master = master
        self.master.title("Chat client")

        # Label "Current online: N"
        self.online_label = tk.Label(master, text="Current online: 0", fg="blue", cursor="hand2")
        self.online_label.pack(pady=(5, 0))

        # When clicked, a window with a list opens
        self.online_label.bind("<Button-1>", self.show_online_users)

        # We store a list of current users locally
        self.current_users = []

        # Message field
        self.text_area = scrolledtext.ScrolledText(master, state='disabled', wrap='word')
        self.text_area.pack(padx=10, pady=10, fill=tk.BOTH, expand=True)

        # Text input field
        self.entry_field = tk.Entry(master)
        self.entry_field.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5, pady=5)
        self.entry_field.bind("<Return>", self.send_message)

        # Submit button
        self.send_button = tk.Button(master, text="Send", command=self.send_message)
        self.send_button.pack(side=tk.RIGHT, padx=5, pady=5)

        # Requesting a username
        self.username = simpledialog.askstring("Username", "Enter your name:", parent=self.master)
        if not self.username:
            self.master.destroy()
            return

        # Connecting to the server
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.connect((HOST, PORT))
        self.running = True

        # Send name
        self.sock.sendall(self.username.encode('utf-8'))

        # Start the receiving stream (line by line)
        self.receive_thread = threading.Thread(target=self.receive_loop)
        self.receive_thread.start()

        # When closing the window
        self.master.protocol("WM_DELETE_WINDOW", self.on_closing)

    def receive_loop(self):
        buffer = ""
        while self.running:
            try:
                data = self.sock.recv(1024)
                if not data:
                    break

                buffer += data.decode('utf-8')
                while "\n" in buffer:
                    line, buffer = buffer.split("\n", 1)
                    line = line.strip()
                    if not line:
                        continue

                    # Checking if this is a service message
                    if line.startswith("ONLINE_USERS:"):
                        self.handle_online_users_message(line)
                    else:
                        # Regular chat message
                        self.display_message(line)

            except:
                break
        self.sock.close()

    def handle_online_users_message(self, message):
        """
        Формат: "ONLINE_USERS:<число> user1 user2 ..."
        """
        parts = message.split()
        # parts[0] = "ONLINE_USERS:3" -> "3"
        count_str = parts[0].split(":")[1]
        count = int(count_str)

        # The remaining elements are names
        users = parts[1:]

        self.online_label.config(text=f"Current online: {count}")
        self.current_users = users

    def display_message(self, message):
        self.text_area.config(state='normal')
        self.text_area.insert(tk.END, message + "\n")
        self.text_area.config(state='disabled')
        self.text_area.see(tk.END)

    def send_message(self, event=None):
        msg = self.entry_field.get().strip()
        if msg:
            self.sock.sendall(msg.encode('utf-8'))
            self.entry_field.delete(0, tk.END)

    def show_online_users(self, event=None):

        # When you click on the inscription “Current online”, a window with a list of users appears.

        top = tk.Toplevel(self.master)
        top.title("List of online users")

        listbox = tk.Listbox(top)
        listbox.pack(padx=10, pady=10, fill=tk.BOTH, expand=True)

        for user in self.current_users:
            listbox.insert(tk.END, user)

    def on_closing(self):
        self.running = False
        self.sock.close()
        self.master.destroy()


def main():
    root = tk.Tk()
    client = ChatClient(root)
    root.mainloop()


if __name__ == "__main__":
    main()
